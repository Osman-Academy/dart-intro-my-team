import 'package:flutter/material.dart';

void main() {
  runApp(const ShrinkSquareApp());
}

class ShrinkSquareApp extends StatelessWidget {
  const ShrinkSquareApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: ShrinkSquareDemo(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class ShrinkSquareDemo extends StatefulWidget {
  const ShrinkSquareDemo({super.key});

  @override
  State<ShrinkSquareDemo> createState() => _ShrinkSquareDemoState();
}

class _ShrinkSquareDemoState extends State<ShrinkSquareDemo> {
  double _size = 200; // initial size of square

  void _shrinkSquare() {
    setState(() {
      // Toggle between small and large size
      _size = _size == 200 ? 80 : 200;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[900],
      body: Center(
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 600),
          curve: Curves.easeInOut,
          width: _size,
          height: _size,
          decoration: BoxDecoration(
            color: Colors.blueAccent,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.blueAccent.withOpacity(0.5),
                blurRadius: 20,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Center(
            child: Text(
              "Size: ${_size.toStringAsFixed(0)}",
              style: const TextStyle(
                  color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _shrinkSquare,
        backgroundColor: Colors.blueAccent,
        child: const Icon(Icons.aspect_ratio),
      ),
    );
  }
}
