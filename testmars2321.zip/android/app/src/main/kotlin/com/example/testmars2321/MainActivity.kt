package com.example.testmars2321

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
