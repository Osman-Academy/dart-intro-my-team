import 'package:freezed_annotation/freezed_annotation.dart';

part 'user.freezed.dart';
part 'user.g.dart';

//flutter packages pub run build_runner build --delete-conflicting-outputs

@freezed
class User with _$User {
  factory User(
      {required String firstName,
      required String lastName,
      @Default(false) bool status,
      @Default("") String middleName}) = _User;
  factory User.fromJson(Map<String, Object?> json) => _$UserFromJson(json);
}
