package com.example.freezed_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
