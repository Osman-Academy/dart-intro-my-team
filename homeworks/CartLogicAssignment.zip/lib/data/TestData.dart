import '../model/Category.dart';
import '../model/Product.dart';

final List<Category> dummyCategories = [
  Category(
    id: '1',
    name: 'Электроника',
    // imageUrl: 'https://via.placeholder.com/150/92c952',
  ),
  Category(
    id: '2',
    name: 'Одежда',
    // imageUrl: 'https://via.placeholder.com/150/771796',
  ),
  Category(
    id: '3',
    name: 'Книги',
    // imageUrl: 'https://via.placeholder.com/150/24f355',
  ),
];

final List<Product> dummyProducts = [
  Product(
    id: '1',
    name: 'Смартфон',
    description: 'Мощный смартфон с отличной камерой',
    price: 29999.99,
    // imageUrl: 'https://via.placeholder.com/300/92c952',
    categoryId: '1',
  ),
  Product(
    id: '2',
    name: 'Ноутбук',
    description: 'Игровой ноутбук для работы и развлечений',
    price: 59999.99,
    // imageUrl: 'https://via.placeholder.com/300/771796',
    categoryId: '1',
  ),
  Product(
    id: '3',
    name: 'Футболка',
    description: 'Хлопковая футболка премиум качества',
    price: 1999.99,
    // imageUrl: 'https://via.placeholder.com/300/24f355',
    categoryId: '2',
  ),
  Product(
    id: '4',
    name: 'Программирование на Dart',
    description: 'Лучшая книга по изучению Dart',
    price: 1499.99,
    // imageUrl: 'https://via.placeholder.com/300/ff7b7b',
    categoryId: '3',
  ),
];
