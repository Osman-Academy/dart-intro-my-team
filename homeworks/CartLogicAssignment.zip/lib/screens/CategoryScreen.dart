import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../model/Product.dart';
import '../data/TestData.dart';
import '../provider/CartProvider.dart';
import '../widgets/ProductCard.dart';

class CategoryScreen extends StatelessWidget {
  const CategoryScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final categoryId = ModalRoute.of(context)!.settings.arguments as String;
    final categoryProducts = dummyProducts
        .where((product) => product.categoryId == categoryId)
        .toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Товары категории'),
      ),
      body: Consumer<CartProvider>(
        builder: (context, cart, child) {
          return GridView.builder(
            padding: const EdgeInsets.all(16),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
              childAspectRatio: 0.7,
            ),
            itemCount: categoryProducts.length,
            itemBuilder: (context, index) {
              final product = categoryProducts[index];
              return ProductCard(
                product: product,
                onAddToCart: () {
                  cart.addItem(product);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('${product.name} добавлен в корзину'),
                      duration: const Duration(seconds: 1),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
