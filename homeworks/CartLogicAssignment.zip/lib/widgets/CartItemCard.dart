import 'package:flutter/material.dart';
import '../model/CartItem.dart';

class CartItemCard extends StatelessWidget {
  final CartItem cartItem;
  final VoidCallback onRemove;

  const CartItemCard({
    Key? key,
    required this.cartItem,
    required this.onRemove,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
      child: ListTile(
        // leading: Image.network(
        //   cartItem.product.imageUrl,
        //   width: 50,
        //   height: 50,
        //   fit: BoxFit.cover,
        // ),
        title: Text(cartItem.product.name),
        subtitle: Text('${cartItem.product.price.toStringAsFixed(2)} ₽'),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: const Icon(Icons.remove),
              onPressed: onRemove,
            ),
            Text('${cartItem.quantity}'),
            IconButton(
              icon: const Icon(Icons.add),
              onPressed: () {}, // Для увеличения количества
            ),
          ],
        ),
      ),
    );
  }
}
