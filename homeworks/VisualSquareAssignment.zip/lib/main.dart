import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: ShrinkingSquare(),
    );
  }
}

class ShrinkingSquare extends StatefulWidget {
  @override
  _ShrinkingSquareState createState() => _ShrinkingSquareState();
}

class _ShrinkingSquareState extends State<ShrinkingSquare>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  double _squareSize = 200.0;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: Duration(seconds: 2),
    );

    _animation = Tween<double>(
      begin: 200.0,
      end: 50.0,
    ).animate(_controller)
      ..addListener(() {
        setState(() {
          _squareSize = _animation.value;
        });
      });
  }

  void _toggleAnimation() {
    if (_controller.isCompleted) {
      _controller.reverse();
    } else {
      _controller.forward();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Shrinking Square')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Визуальный квадрат с динамическими изменениями
            AnimatedContainer(
              duration: Duration(milliseconds: 500),
              width: _squareSize,
              height: _squareSize,
              decoration: BoxDecoration(
                color: Colors.blue,
                borderRadius: BorderRadius.circular(8),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 10,
                    offset: Offset(0, 5),
                  ),
                ],
              ),
              child: Center(
                child: Text(
                  '${_squareSize.toInt()}px',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),

            SizedBox(height: 20),

            // Кнопки управления
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () => setState(() => _squareSize -= 20),
                  child: Text('Shrink -20'),
                ),
                SizedBox(width: 10),
                ElevatedButton(
                  onPressed: () => setState(() => _squareSize += 20),
                  child: Text('Grow +20'),
                ),
              ],
            ),

            ElevatedButton(
              onPressed: _toggleAnimation,
              child: Text('Animate Shrink/Grow'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}
