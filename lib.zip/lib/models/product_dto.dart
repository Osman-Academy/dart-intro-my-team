class ProductDto {
  String? name;
  int? productId;
  ProductDto({this.name, this.productId});
}
