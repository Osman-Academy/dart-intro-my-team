import 'package:blocitro/sum_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class Calc extends StatelessWidget {
  TextEditingController controllerA = TextEditingController();
  TextEditingController controllerB = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Form(
      child: BlocBuilder<SumCubit, double>(builder: (context, sum) {
        return Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          spacing: 20,
          children: [
            TextFormField(
              controller: controllerA,
              decoration: const InputDecoration(
                  label: Text("Num A"), border: OutlineInputBorder()),
            ),
            TextFormField(
              controller: controllerB,
              decoration: const InputDecoration(
                  label: Text("Num B"), border: OutlineInputBorder()),
            ),
            ElevatedButton(
                onPressed: () {
                  context.read<SumCubit>().add(double.parse(controllerA.text),
                      double.parse(controllerB.text));
                },
                child: const Text("add")),
            Row(children: [const Text("result :"), Text(sum.toString())]),
            Container(
              width: sum,
              height: sum,
              decoration:
                  BoxDecoration(shape: BoxShape.rectangle, color: Colors.red),
            )
          ],
        );
      }),
    );
  }
}
