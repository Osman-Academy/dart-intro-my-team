package com.example.logger_sample

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
