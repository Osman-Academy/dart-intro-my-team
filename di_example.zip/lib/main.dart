import 'package:di_example/common/conf/config.dart';
import 'package:di_example/common/services/sentry_logger.dart';
import 'package:di_example/usecases/car_usecase.dart';
import 'package:flutter/material.dart';
import 'package:di_example/models/car.dart';
import 'package:di_example/common/services/logger_service.dart';
import 'package:di_example/common/di/service_locator.dart';
import 'package:sentry_flutter/sentry_flutter.dart';

Future<void> main() async {
  setupLocator();
  await SentryLoggerService.init(Config.sentryDsn, () => runApp(const MyApp()));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    logger.d("This line has a bug!");
    logger.e("Error ok");
    Sentry.logger.fmt.error('Uh oh, something broke, here is the error: %s', [
      "Error is occured"
    ], attributes: {
      'additional_info': SentryLogAttribute.string('some info'),
    });
    return MaterialApp(
      // Application name
      title: 'Flutter Hello World',
      // Application theme data, you can set the colors for the application as
      // you want
      theme: ThemeData(
        // useMaterial3: false,
        primarySwatch: Colors.blue,
      ),
      // A widget which will be started on application startup
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatelessWidget {
  final String title;
  const MyHomePage({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    CarUsecase usecase = CarUsecase(carRepo: sl());
    List<Car> cars = usecase.carRepo.getCars();
    return Scaffold(
      appBar: AppBar(
        // The title text which will be shown on the action bar
        title: Text(title),
      ),
      body: ListView.builder(
          itemCount: cars.length,
          itemBuilder: (BuildContext context, int index) {
            return SizedBox(
              height: 50,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Text(cars[index].model),
                  Text(cars[index].carEngine.name),
                  Text(cars[index].carEngine.volume.toString())
                ],
              ),
            );
          }),
    );
  }
}
