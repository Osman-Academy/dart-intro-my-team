import 'package:get_it/get_it.dart';
import 'package:di_example/repositories/car_repository.dart';

GetIt sl = GetIt.instance;

void setupLocator() {
  sl.registerSingleton<CarRepository>(
    CarRepositoryImpl(),
    signalsReady: true,
  );
}
