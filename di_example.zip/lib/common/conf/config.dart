class Config {
  static String sentryDsn =
      "https://07e26b18efb5b0298ae6e220d2b56196@o1399056.ingest.us.sentry.io/4510502715326465";
}
