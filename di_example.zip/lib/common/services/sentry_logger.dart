import 'package:sentry/sentry.dart';
import 'package:sentry_flutter/sentry_flutter.dart';
import 'package:sentry_logging/sentry_logging.dart';

class SentryLoggerService {
  static Future<void> init(String dsn, Function()? initApp) async {
    Sentry.init(
      (options) {
        options.dsn = dsn;
        options.enableLogs = true;
        options.integrations
            .add(LoggingIntegration()); // Replace with your actual DSN
        // Other Sentry options can be configured here
      },
      appRunner: initApp, // Function to run your Flutter app
    );
  }
}
