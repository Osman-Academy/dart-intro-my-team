import 'package:di_example/models/engine.dart';

class Car {
  String model;
  Engine carEngine;

  Car(this.model, this.carEngine);

  factory Car.fromJson(Map<String, dynamic> json) {
    return Car(json["model"], Engine.fromJson(json["carEngine"]));
  }
}
