class Engine {
  String name;
  double volume;

  Engine(this.name, this.volume);

  factory Engine.fromJson(Map<String, dynamic> json) {
    return Engine(json["name"], json["volume"]);
  }
}
