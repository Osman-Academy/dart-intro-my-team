import 'package:di_example/models/car.dart';

abstract class CarRepository {
  List<Car> getCars();
}

var dataFromServer = [
  {
    "model": "Toyota",
    "carEngine": {"name": "2jzgte", "volume": 2.5}
  },
  {
    "model": "Lexus LX470",
    "carEngine": {"name": "3UZFe", "volume": 4.7}
  },
];

class CarRepositoryImpl implements CarRepository {
  @override
  List<Car> getCars() {
    return dataFromServer.map((e) => Car.fromJson(e)).toList();
  }
}

class CarRepositoryImplWithT implements CarRepository {
  @override
  List<Car> getCars() {
    return dataFromServer.map((e) => Car.fromJson(e)).where((element) {
      return element.model.contains("t");
    }).toList();
  }
}
