import 'package:di_example/repositories/car_repository.dart';

class CarUsecase {
  CarRepository carRepo;
  CarUsecase({required this.carRepo});
}
