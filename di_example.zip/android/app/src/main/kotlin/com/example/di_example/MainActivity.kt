package com.example.di_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
