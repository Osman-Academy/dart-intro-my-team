import 'package:flutter/material.dart';

class Counter {
  int value = 0;

  void increment() => value++;

  void decrement() => value--;
}

class UnitNotifier {
  static void valueChanged(String value) {
    print("Value is changed this is UnitNotifier: $value");
  }
}

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // Application name
      title: 'Flutter Hello World',
      // Application theme data, you can set the colors for the application as
      // you want
      theme: ThemeData(
        // useMaterial3: false,
        primarySwatch: Colors.blue,
      ),
      // A widget which will be started on application startup
      home: MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatelessWidget {
  final String title;
  MyHomePage({super.key, required this.title});
  final Counter cnt = Counter();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // The title text which will be shown on the action bar
        title: Text(title),
      ),
      body: StatefulBuilder(
        builder: (context, setState) {
          return Center(
            child: Column(
              children: [
                Text(cnt.value.toString(), key: Key('resultValue')),
                ElevatedButton(
                    key: Key('btnIncrement'),
                    onPressed: () {
                      setState(() {
                        cnt.increment();
                      });
                      UnitNotifier.valueChanged(cnt.value.toString());
                    },
                    child: Text("increment")),
                ElevatedButton(
                    key: Key('btnDecrement'),
                    onPressed: () {
                      setState(() {
                        cnt.decrement();
                      });
                    },
                    child: Text("decrement"))
              ],
            ),
          );
        },
      ),
    );
  }
}
