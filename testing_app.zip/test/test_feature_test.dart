// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

//#Important! Click the "generate tests" button if you have made any changes to this file.

//#Read more about Gherkin syntax https://cucumber.io/docs/gherkin/reference/
//#Read more about bdd_widget_test package https://pub.dev/packages/bdd_widget_test

//#Example of BDD(Gherkin) syntax:
//#
//#Feature: Counter
//#  Scenario: Initial counter value is 0
//#    Given the app is running
//#    Then I see {'0'} text
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:testing_app/main.dart';

void main() {
  //BDD Build Driven Design

  testWidgets('App starts and displays text', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(const MyApp());

    group('App Form1', () {});

    group('App Form2', () {});

    Counter cnt = Counter();
    cnt.increment();
    expect(cnt.value, 1);
    UnitNotifier.valueChanged(cnt.value.toString());

    // Verify that the text "App is running" is present.
    var incText = find.byKey(Key('resultValue'));
    expect(find.byKey(Key('resultValue')), findsOneWidget);

    expect(find.byKey(Key('btnIncrement')), findsOneWidget);
    await tester.tap(find.byKey(Key('btnIncrement')));
    await tester.pump();
    await tester.tap(find.byKey(Key('btnIncrement')));
    await tester.pump();
    expect(tester.widget<Text>(incText).data, "2");
    await tester.tap(find.byKey(Key('btnDecrement')));
    await tester.pump();
    expect(tester.widget<Text>(incText).data, "1");
  });
}
